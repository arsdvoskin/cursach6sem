package com.example.course_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
