enum DialogType {
  error,
  success,
  info;
}
